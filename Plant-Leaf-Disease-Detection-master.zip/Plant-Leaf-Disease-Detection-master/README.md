# Plant-Leaf-Disease-Detection
Plant Leaf Disease Detection using Tensorflow &amp; OpenCV in Python
