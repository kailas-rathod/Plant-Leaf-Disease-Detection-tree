# food-recocgniztion
Recognize food with Python, Google vision, OpenCV

# Requirements:
- Python 3
- GCP account (To use google vision)
- OpenCV (To scale image only)
# Libs
pip install --upgrade google-cloud-vision

pip install --upgrade opencv-python
